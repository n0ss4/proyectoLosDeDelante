package com.DAW1;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import acm.graphics.GImage;
import acm.program.GraphicsProgram;


class Main {
        Scanner teclado = new Scanner(System.in);

        public static void main(String[] args) {
                new App().start(args);
        }

        public static class App extends GraphicsProgram {
                public final void run() {
                        GImage tablero = new GImage("tablero.jpg");
                        ArrayList<Jugador> arrayjugadors = new ArrayList<Jugador>();
                        String[] caselles = new String[63];


                        Partida.llenar(caselles);
                        int[] separatint = new int[2];

                        System.out.println("Quants jugadors jugaran");
                        int numero_jugadors = 2;
                        add(tablero);
                        tablero.setSize((int) tablero.getWidth() - 200, (int) tablero.getHeight() - 200);
                        setSize((int) tablero.getWidth() + 20, (int) tablero.getHeight() + 70);


                        for (int i = 0; i < numero_jugadors; i++) {
                                switch (i) {
                                        case 0:
                                                arrayjugadors.add(new Jugador("r.png"));
                                                break;
                                        case 1:
                                                arrayjugadors.add(new Jugador("a.png"));
                                                break;
                                        case 2:
                                                arrayjugadors.add(new Jugador("v.png"));
                                                break;
                                }
                                add(arrayjugadors.get(i).getFicha());
                                arrayjugadors.get(i).getFicha().setSize(40, 40);
                                arrayjugadors.get(i).getFicha().setLocation(336, tablero.getHeight() - arrayjugadors.get(i).getFicha().getHeight());
                                arrayjugadors.get(i).getFicha().move(36, -36);
                        }

                        Random random = new Random();

                        boolean llega = false;
                        int k = 0;
                        System.out.println(arrayjugadors.size());
                        while (!llega) {
                                System.out.println("jugador nº"+(k+1));
                                arrayjugadors.get(k).tirada();
                                System.out.println(arrayjugadors.get(k).getNumero());
                                arrayjugadors.get(k).setPosiciondondeesta(arrayjugadors.get(k).getPosiciondondeesta() + arrayjugadors.get(k).getNumero());
                                if (arrayjugadors.get(k).getTurnodeespera() != 0) {
                                        arrayjugadors.get(k).setTurnodeespera(arrayjugadors.get(k).getTurnodeespera() - 1);
                                } else if (arrayjugadors.get(k).getPosiciondondeesta()+arrayjugadors.get(k).getNumero() == 63) {
                                        llega = true;
                                } else if ((arrayjugadors.get(k).getPosiciondondeesta() + arrayjugadors.get(k).getNumero() > 63)) {
                                        int casillasparaatras = (arrayjugadors.get(k).getPosiciondondeesta() + arrayjugadors.get(k).getNumero()) - 63;
                                        for (int i = arrayjugadors.get(k).getPosiciondondeesta(); i < 63; i++) {
                                                strintotint(separatint, caselles, arrayjugadors.get(k).getPosiciondondeesta());
                                                arrayjugadors.get(k).getFicha().move(separatint[0], separatint[1]);
                                                arrayjugadors.get(k).getFicha().pause(250);
                                        }
                                        arrayjugadors.get(k).getFicha().move(110, 0);
                                        switch (casillasparaatras) {
                                                case 1:
                                                        arrayjugadors.get(k).getFicha().move(-110, 0);
                                                        arrayjugadors.get(k).setPosiciondondeesta(62);
                                                        break;
                                                case 2:
                                                        arrayjugadors.get(k).getFicha().move(-110, -110);
                                                        arrayjugadors.get(k).setPosiciondondeesta(61);
                                                        break;
                                                case 3:
                                                        arrayjugadors.get(k).getFicha().move(-110, -110 * 2);
                                                        arrayjugadors.get(k).setPosiciondondeesta(60);
                                                        break;
                                                case 4:
                                                        arrayjugadors.get(k).setPosiciondondeesta(63);
                                                        llega = true;
                                                        break;
                                                case 5:
                                                        arrayjugadors.get(k).getFicha().setLocation(336 + 36, (tablero.getHeight() - arrayjugadors.get(k).getFicha().getHeight() - 36));
                                                        arrayjugadors.get(k).setPosiciondondeesta(0);
                                        }

                                } else {
                                        arrayjugadors.get(k).setPosiciondondeesta(arrayjugadors.get(k).getPosiciondondeesta()-arrayjugadors.get(k).getNumero());
                                        for (int i = 0; i < arrayjugadors.get(k).getNumero(); i++) {
                                                strintotint(separatint, caselles, arrayjugadors.get(k).getPosiciondondeesta());
                                                arrayjugadors.get(k).getFicha().move(separatint[0], separatint[1]);
                                                arrayjugadors.get(k).getFicha().pause(250);
                                                arrayjugadors.get(k).setPosiciondondeesta(arrayjugadors.get(k).getPosiciondondeesta() + 1);
                                        }

                                        if (Partida.casillaconefecto(arrayjugadors.get(k).getPosiciondondeesta())) {
                                                switch (arrayjugadors.get(k).getPosiciondondeesta()) {
                                                        case 5:
                                                                arrayjugadors.get(k).getFicha().move(5, -112 * 4);
                                                                arrayjugadors.get(k).setPosiciondondeesta(9);
                                                                System.out.println("De Oca en oca");
                                                                break;
                                                        case 6:
                                                                arrayjugadors.get(k).getFicha().move(5, -112 * 6);
                                                                arrayjugadors.get(k).setPosiciondondeesta(12);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 9:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 2, -112 * 3);
                                                                arrayjugadors.get(k).setPosiciondondeesta(14);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 12:
                                                                arrayjugadors.get(k).getFicha().move(0, 110 * 6);
                                                                arrayjugadors.get(k).setPosiciondondeesta(6);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 14:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 4, 0);
                                                                arrayjugadors.get(k).setPosiciondondeesta(18);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 18:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 2, 110 * 3);
                                                                arrayjugadors.get(k).setPosiciondondeesta(23);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 19:
                                                                arrayjugadors.get(k).setTurnodeespera(2);
                                                                break;
                                                        case 23:
                                                                arrayjugadors.get(k).getFicha().move(110, 110 * 3);
                                                                arrayjugadors.get(k).setPosiciondondeesta(27);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 26:
                                                                arrayjugadors.get(k).getFicha().move(110 * 5, -110);
                                                                arrayjugadors.get(k).setPosiciondondeesta(52);
                                                                System.out.println("De puente en puente");
                                                                arrayjugadors.get(k).setTurnodeespera(3);
                                                                break;

                                                        case 27:
                                                                arrayjugadors.get(k).getFicha().move(110 * 5, 0);
                                                                arrayjugadors.get(k).setPosiciondondeesta(32);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 32:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 2, -110 * 5);
                                                                arrayjugadors.get(k).setPosiciondondeesta(41);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 41:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 3, 110);
                                                                arrayjugadors.get(k).setPosiciondondeesta(45);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 42:
                                                                arrayjugadors.get(k).getFicha().move(110, 110 * 5);
                                                                arrayjugadors.get(k).setPosiciondondeesta(30);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 45:
                                                                arrayjugadors.get(k).getFicha().move(110 * 3, 110 * 2);
                                                                arrayjugadors.get(k).setPosiciondondeesta(50);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 50:
                                                                arrayjugadors.get(k).getFicha().move(110 * 3, -110);
                                                                arrayjugadors.get(k).setPosiciondondeesta(54);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 52:
                                                                arrayjugadors.get(k).setTurnodeespera(3);
                                                                break;
                                                        case 53:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 6, -110 * 2);
                                                                arrayjugadors.get(k).setPosiciondondeesta(23);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 54:
                                                                arrayjugadors.get(k).getFicha().move(-110 * 2, -110 * 3);
                                                                arrayjugadors.get(k).setPosiciondondeesta(59);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 58:
                                                                arrayjugadors.get(k).getFicha().setLocation(336 + 36, (tablero.getHeight() - arrayjugadors.get(k).getFicha().getHeight() - 36));
                                                                arrayjugadors.get(k).setPosiciondondeesta(0);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                        case 59:
                                                                arrayjugadors.get(k).getFicha().move(110 * 1.5, 110 * 1.5);
                                                                arrayjugadors.get(k).setPosiciondondeesta(63);
                                                                System.out.println("De puente en puente");
                                                                break;
                                                }
                                        }
                                }arrayjugadors.get(k).getFicha().pause(3000);
                                System.out.println(arrayjugadors.get(k).getPosiciondondeesta());
                                if (k == numero_jugadors-1) {
                                        k=0;
                                }else { k++;}
                        }
                }
        }

        public static void strintotint(int[] separatint, String[] caselles, int posicion) {
                String[] separat = caselles[posicion].split(";");
                for (int j = 0; j < separatint.length; j++) {
                        separatint[j] = Integer.parseInt(separat[j]);
                }
        }

}

